import ast
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

BASE = Path('/tmp/cc-m3-quality-independent.vVWnzT')
SOURCE = Path('/Users/litmus/Documents/Contract Capsule/.worktrees/m3-post-audit-hotfix-2')
PYTHON = str(SOURCE / '.venv/bin/python')
HEAD = BASE / 'head'
OLD = BASE / 'baseline'

def environment(root):
    env = dict(os.environ)
    env.update(PYTHONPATH=f'{root}/src:{root}', PYTHONDONTWRITEBYTECODE='1',
               PYTHONPYCACHEPREFIX=str(BASE / 'cache/bytecode'),
               HYPOTHESIS_STORAGE_DIRECTORY=str(BASE / 'cache/hypothesis'),
               MYPY_CACHE_DIR=str(BASE / 'cache/mypy'),
               RUFF_CACHE_DIR=str(BASE / 'cache/ruff'),
               UV_CACHE_DIR=str(BASE / 'cache/uv'), UV_OFFLINE='1')
    return env

def run(label, args, root=HEAD):
    command = [PYTHON, '-m', *args] if args[0] != 'uv' else args
    result = subprocess.run(command, cwd=root, env=environment(root), text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (BASE / f'{label}.log').write_text(result.stdout)
    print(json.dumps({'label':label,'cwd':str(root),'command':command,
                      'exit':result.returncode,'output':result.stdout}), flush=True)
    return result

def pytest(label, args, root=HEAD):
    return run(label, ['pytest', *args, '-o', f'cache_dir={BASE}/cache/pytest'], root)

def inventory(root):
    return {str(Path(directory, filename).relative_to(root))
            for prefix in ('src/contractcapsule', 'tests')
            for directory, _, filenames in os.walk(root / prefix)
            for filename in filenames if filename.endswith('.py')}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

if sys.argv[1] == 'gates':
    run('import-proof', ['site'])
    pytest('new13', ['tests/unit/test_lint_discovery.py', 'tests/unit/test_source_ingestion_regression.py','-q','-ra'])
    pytest('m3', ['tests/integration/test_build_pipeline.py','tests/security/test_trust_promotion.py','tests/security/test_trust_gate_remediation.py','-q','-ra'])
    pytest('m2', ['tests/unit/test_models.py','tests/unit/test_package_loader.py','tests/unit/test_schema_python_parity.py','tests/unit/test_cas.py','tests/unit/test_registry.py','tests/property/test_immutability.py','-q','-ra'])
    pytest('formal-lock-ledger', ['tests/fixtures/formal_cases','tests/unit/test_spec_lock.py','tests/unit/test_ai_usage_ledger.py','-q','-ra'])
    pytest('full', ['-q','-ra'])
    run('ruff-default', ['ruff','check','.'])
    run('ruff-noignore', ['ruff','check','src/contractcapsule','tests','--no-respect-gitignore','--no-cache'])
    run('complexity', ['ruff','check','src/contractcapsule','tests','--select','C901,PLR0911,PLR0912,PLR0915'])
    run('complexity-noignore', ['ruff','check','src/contractcapsule','tests','--select','C901,PLR0911,PLR0912,PLR0915','--no-respect-gitignore','--no-cache'])
    run('mypy', ['mypy','.'])
    run('lock', ['uv','lock','--check','--offline'])
if sys.argv[1] == 'inventory':
    for suffix in ([], ['--no-respect-gitignore']):
        result = run('inventory-' + ('noignore' if suffix else 'default'), ['ruff','check','src/contractcapsule','tests','--show-files',*suffix])
        actual = {str(Path(line).resolve().relative_to(HEAD.resolve())) for line in result.stdout.splitlines() if line.endswith('.py')}
        expected = inventory(HEAD)
        assert actual == expected, (expected - actual, actual - expected)
        print('INVENTORY', len(expected), 'SOURCE', sum(p.startswith('src/') for p in expected), 'TEST', sum(p.startswith('tests/') for p in expected), 'BUILDER', sorted(p for p in expected if p.startswith('src/contractcapsule/build/')), flush=True)
if sys.argv[1] == 'baseline':
    original = pytest('baseline-nodes', ['--collect-only','-q'], OLD)
    final = pytest('head-nodes', ['--collect-only','-q'])
    old_nodes = {line for line in original.stdout.splitlines() if '::' in line}
    new_nodes = {line for line in final.stdout.splitlines() if '::' in line}
    assert len(old_nodes) == 326 and len(new_nodes) == 339
    assert old_nodes <= new_nodes
    original_files = sorted(OLD.joinpath('tests').rglob('*'))
    differences = [str(p.relative_to(OLD)) for p in original_files if p.is_file() and sha(p) != sha(HEAD / p.relative_to(OLD))]
    assert not differences, differences
    print('TEST_PRESERVATION',len(old_nodes),len(new_nodes),'unchanged files',sum(p.is_file() for p in original_files), flush=True)
    shutil.copyfile(HEAD / 'tests/unit/test_source_ingestion_regression.py', OLD / 'tests/unit/test_source_ingestion_regression.py')
    pytest('baseline-characterization', ['tests/unit/test_source_ingestion_regression.py','-q','-ra'], OLD)
if sys.argv[1] == 'structural':
    old_tree = ast.parse((OLD / 'src/contractcapsule/build/ingest.py').read_text())
    new_tree = ast.parse((HEAD / 'src/contractcapsule/build/ingest.py').read_text())
    old_defs = {node.name:node for node in old_tree.body if isinstance(node,(ast.FunctionDef, ast.ClassDef))}
    new_defs = {node.name:node for node in new_tree.body if isinstance(node,(ast.FunctionDef, ast.ClassDef))}
    added = set(new_defs) - set(old_defs)
    assert added == {'_read_source_content','_validate_source_content'}
    for name in old_defs:
        if name != '_snapshot_source':
            assert ast.dump(old_defs[name]) == ast.dump(new_defs[name]), name
    old_snapshot = old_defs['_snapshot_source']
    new_snapshot = new_defs['_snapshot_source']
    assert ast.dump(old_snapshot.args) == ast.dump(new_snapshot.args)
    assert ast.dump(old_snapshot.returns) == ast.dump(new_snapshot.returns)
    expanded = []
    for statement in new_snapshot.body:
        if isinstance(statement, ast.Assign) and isinstance(statement.value, ast.Call) and isinstance(statement.value.func, ast.Name) and statement.value.func.id in added:
            helper = new_defs[statement.value.func.id]
            expanded.extend(helper.body[1:-1])
        else:
            expanded.append(statement)
    assert [ast.dump(n) for n in old_snapshot.body] == [ast.dump(n) for n in expanded]
    print('AST: all original definitions/signatures identical; expanded _snapshot_source sequence exactly identical',flush=True)
    for root in (HEAD,OLD):
        code = 'import contractcapsule,contractcapsule.build.ingest as i; print(contractcapsule.__file__); print(i.__file__)'
        result = subprocess.run([PYTHON,'-c',code],cwd=root,env=environment(root),capture_output=True,text=True,check=True)
        print('IMPORT',root,result.stdout,flush=True)
        assert all(Path(line).resolve().is_relative_to(root.resolve()) for line in result.stdout.splitlines())
    files = subprocess.check_output(['git','ls-tree','-r','--name-only','2294af30ade13e1aad5507a85976cd80f425c2fc'],cwd=SOURCE,text=True).splitlines()
    bad = [p for p in files if sha(HEAD / p) != sha(SOURCE / p)]
    assert not bad, bad
    print('HEAD_ARCHIVE_SOURCE_IDENTICAL',len(files),'files',flush=True)
if sys.argv[1] == 'pytest':
    pytest(sys.argv[2], sys.argv[3:])
if sys.argv[1] == 'worktree-inventory':
    command = [PYTHON,'-m','ruff','check','src/contractcapsule','tests','--show-files','--no-cache']
    result = subprocess.run(command,cwd=SOURCE,env=environment(HEAD),capture_output=True,text=True,check=True)
    actual = {str(Path(line).resolve().relative_to(SOURCE.resolve())) for line in result.stdout.splitlines() if line.endswith('.py')}
    expected = inventory(SOURCE)
    assert actual == expected
    (BASE / 'worktree-inventory.log').write_text(result.stdout)
    print('WORKTREE_INVENTORY',len(actual),'equals independent os.walk inventory;',command)
