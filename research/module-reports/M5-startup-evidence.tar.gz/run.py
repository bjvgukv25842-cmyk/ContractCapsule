"""Preserve exact M5 preparation commands and their output without log replacement."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).parent.resolve()
label, cwd, *command = sys.argv[1:]
path = ROOT / (label + '.log')
assert not path.exists(), 'preserve previous command evidence'
result = subprocess.run(command, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
path.write_bytes(result.stdout)
record = {'label':label,'cwd':cwd,'argv':command,'exit':result.returncode,
          'sha256':hashlib.sha256(result.stdout).hexdigest()}
with (ROOT/'commands.jsonl').open('a') as stream:
    stream.write(json.dumps(record)+'\n')
print(result.stdout.decode(errors='replace'))
print(json.dumps(record))
raise SystemExit(result.returncode)
