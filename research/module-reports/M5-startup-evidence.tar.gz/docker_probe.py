"""Inspect a disposable no-network container; never mount user paths or pull images."""
import json
import re
import subprocess

IMAGE = 'sha256:090ba77e2958f6af52a5341f788b50b032dd4ca28377d2893dcf1ecbdfdfe203'
PROGRAM = '''
import os,json,pathlib,platform
p=pathlib.Path
status={k:v.strip() for k,v in (line.split(':',1) for line in p('/proc/self/status').read_text().splitlines())}
flags={item.name:int((item/'flags').read_text(),0) for item in p('/sys/class/net').iterdir() if item.is_dir()}
routes=p('/proc/net/route').read_text().splitlines()[1:]
data={'python':platform.python_version(),'uid':os.getuid(),'interface_flags':flags,
      'ipv4_routes':routes,'memory_max':p('/sys/fs/cgroup/memory.max').read_text().strip(),
      'pids_max':p('/sys/fs/cgroup/pids.max').read_text().strip(),
      'cpu_max':p('/sys/fs/cgroup/cpu.max').read_text().strip(),
      'no_new_privs':status.get('NoNewPrivs'),'caps_effective':status.get('CapEff'),
      'root_readonly':bool(os.statvfs('/').f_flag & os.ST_RDONLY),
      'socket_mounted':p('/var/run/docker.sock').exists()}
print(json.dumps(data),flush=True)
assert data['uid']==65534 and not routes and all(name=='lo' or not value & 1 for name,value in flags.items())
assert data['memory_max']=='1073741824' and data['pids_max']=='128' and data['cpu_max']=='100000 100000'
assert data['no_new_privs']=='1' and int(data['caps_effective'],16)==0 and data['root_readonly'] and not data['socket_mounted']
'''

def command(*args):
    return subprocess.run(['docker',*args],check=True,capture_output=True,text=True,timeout=30).stdout

identifier=command('create','--pull=never','--network=none','--read-only','--user=65534:65534',
                   '--cap-drop=ALL','--security-opt=no-new-privileges','--cpus=1',
                   '--memory=1g','--memory-swap=1g','--pids-limit=128',
                   '--tmpfs=/tmp:rw,nosuid,nodev,noexec,size=16m',IMAGE,'python','-I','-c',PROGRAM).strip()
assert re.fullmatch('[a-f0-9]{64}',identifier)
try:
    container=json.loads(command('inspect',identifier))[0]
    host=container['HostConfig']
    assert host['NetworkMode']=='none' and host['ReadonlyRootfs'] and not host['Privileged']
    assert not container['Mounts'] and not host.get('Binds')
    print(json.dumps({'container':identifier,'network':host['NetworkMode'],
                      'readonly_root':host['ReadonlyRootfs'],'image':container['Image'],
                      'binds':host.get('Binds'),'mounts':container['Mounts']}),flush=True)
    print(command('start','-a',identifier),end='',flush=True)
    exit_code=json.loads(command('inspect',identifier))[0]['State']['ExitCode']
    assert exit_code==0,exit_code
finally:
    state=json.loads(command('inspect',identifier))[0]['State']
    if state['Running']:
        command('stop','--time','1',identifier)
    command('rm',identifier)
    print('Removed only the disposable preflight container '+identifier,flush=True)
