"""Old/candidate behavior comparison and independent scope-boundary variant."""
import hashlib
import importlib.util
import os
import sys
import types
from dataclasses import replace
from pathlib import Path
from unittest.mock import patch

from contractcapsule.compile.errors import CompileError
from contractcapsule.compile.evidence import _source_span
from contractcapsule.resolve.graph import resolve_graph
from tests.unit.test_dependency_closure import ReusedApprovalFixture, admit, dependencies, edge
from tests.unit.test_eligibility import task_context, AS_OF, READER
from tests.unit.test_evidence_handles import native_publication

ROOT = Path(__file__).parent
mode = sys.argv[1]
if mode == 'old':
    # Import only the existing regression definitions against old source; the
    # legacy-only new helper is substituted with the old extraction boundary.
    shim = types.ModuleType('contractcapsule.compile.git_evidence')
    shim.validate_git_locator = lambda record, text: _source_span(record, text.encode())
    sys.modules[shim.__name__] = shim
spec = importlib.util.spec_from_file_location(
    'repair_regressions', ROOT / 'candidate/tests/unit/test_service_review_regressions.py')
reg = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reg)

cases = []
for source in ('a', 'com.example.owner'):
    for kind in ('requires', 'conflicts'):
        cases.append((f'foreign-{source}-{kind}', lambda p,s=source,k=kind:
                      reg.test_foreign_graph_sources_cannot_rewrite_owner_dependencies(p,k,s)))
cases += [('release', reg.test_capsule_source_edges_are_bound_to_declaring_release),
          ('legacy-anchor', reg.test_legacy_git_locator_still_requires_real_anchor),
          ('offline', reg.test_missing_promised_git_object_never_starts_fetch)]
for fault in ('different_span', 'locator_heading'):
    cases.append((fault, lambda p,f=fault: reg.test_git_excerpt_stays_bound_to_approval_and_stable_anchor(p,f)))
for name, call in cases:
    path = ROOT / f'{mode}-{name}'
    path.mkdir()
    try:
        call(path)
        print(name, 'PASS')
    except BaseException as error:
        print(name, 'FAIL', type(error).__name__, str(error))

path = ROOT / f'{mode}-denied-owner'
path.mkdir()
fixture = ReusedApprovalFixture.create(path)
first = fixture.publish(atoms=({'atom_id':'a', 'scope':('path:src/only.py',)},))
def narrow(raw):
    raw['control_manifest']['scope']['paths'] = ['src/other/**']
    dependencies((), (), (edge('a','absent'),))(raw)
second = fixture.publish(capsule_id='com.example.second', amend=narrow)
task = task_context(paths=('src/only.py', 'src/other/file.py'))
admission = admit(fixture, (first, second), task)
print('variant admitted membership:', [(p.published.capsule.control_manifest.capsule_id,p.atom_ids) for p in admission.items])
graph = resolve_graph(admission, task)
print('variant source owners:', [r.capsule_id for r in graph.owners['a']])
try:
    print('variant closure:', sorted(graph.close_atoms({'a'})))
except CompileError as error:
    print('variant closure blocked by denied owner:', error.code)
