"""Read-only repository review repro; fixture writes stay in a new physical tmpdir."""
import tempfile
from pathlib import Path
from contractcapsule.compile.errors import CompileError
from contractcapsule.resolve.graph import resolve_graph
from tests.unit.test_dependency_closure import ReusedApprovalFixture, admit, dependencies, edge
from tests.unit.test_eligibility import task_context

root = Path(tempfile.mkdtemp(prefix='denied-owner-', dir=Path(__file__).parent))
fixture = ReusedApprovalFixture.create(root)
first = fixture.publish(atoms=({'atom_id': 'a', 'scope': ('path:src/only.py',)},))

def narrow(raw):
    raw['control_manifest']['scope']['paths'] = ['src/other/**']
    dependencies((), (), (edge('a', 'absent'),))(raw)

second = fixture.publish(capsule_id='com.example.second', amend=narrow)
task = task_context(paths=('src/only.py', 'src/other/file.py'))
admission = admit(fixture, (first, second), task)
print('admission:', [(x.published.capsule.control_manifest.capsule_id, x.atom_ids) for x in admission.items])
graph = resolve_graph(admission, task)
print('owners:', [ref.capsule_id for ref in graph.owners['a']])
try:
    closed = graph.close_atoms({'a'})
except CompileError as error:
    raise AssertionError('Denied owner contributed dependency: ' + error.code) from error
assert closed == {'a'}, closed
