"""Independent review runner; all outputs and fixtures stay in this directory."""
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).parent
PYTHON = Path('/Users/litmus/Documents/Contract Capsule/.worktrees/m4-view-compiler/.venv/bin/python')
mode = sys.argv[1]
tree = ROOT / ('old' if mode == 'old' else 'candidate')
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONPATH=f'{tree}/src:{tree}',
           HYPOTHESIS_STORAGE_DIRECTORY=str(ROOT / 'hypothesis'))
if mode == 'candidate':
    args = ['-m', 'pytest', '-vv', '-p', 'no:cacheprovider',
            '--basetemp', str(ROOT / 'pytest-candidate'),
            'tests/unit/test_service_review_regressions.py']
else:
    args = [str(ROOT / 'variants.py'), mode]
result = subprocess.run([str(PYTHON), *args], cwd=tree, env=env,
                        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=60)
log = f'COMMAND: {PYTHON} {args!r}\nCWD: {tree}\nPYTHONPATH: {env["PYTHONPATH"]}\nEXIT: {result.returncode}\n{result.stdout}'
(ROOT / f'{mode}.log').write_text(log)
print(log)
sys.exit(result.returncode)
