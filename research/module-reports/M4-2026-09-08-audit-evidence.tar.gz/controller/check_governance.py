"""Coordinator-owned artifact checks, not independent implementation approval."""

import gzip
import hashlib
import json
import os
import subprocess
from pathlib import Path

ROOT = Path(__file__).parent.resolve()
SOURCE = Path('/Users/litmus/Documents/Contract Capsule/.worktrees/m4-view-compiler')
ARCHIVE = ROOT / 'governance'
BASELINE = ROOT / 'baseline'
PYTHON = SOURCE / '.venv/bin/python'
RESULTS = []


def record(name, value):
    RESULTS.append({'check': name, 'result': value})
    print(json.dumps(RESULTS[-1]), flush=True)


def git(*args):
    return subprocess.check_output(['git', *args], cwd=SOURCE)


def verify():
    record('governance_commit', git('rev-parse', 'cd6cfcf').decode().strip())
    record('technical_commit', git('rev-parse', '2ce1653').decode().strip())
    files = git('diff', '--name-only', '2ce1653..cd6cfcf').decode().splitlines()
    assert all(name.startswith('research/') for name in files)
    record('governance_only_changed_paths', len(files))
    protected = ['docs/spec/CCS-2.1.md',
                 'docs/superpowers/plans/2026-07-30-contract-capsule-fse-2027-execution-plan.md',
                 'docs/protocol/formal-model.md', 'src/contractcapsule/formal.py']
    for name in protected:
        assert (ARCHIVE/name).read_bytes() == (BASELINE/name).read_bytes()
    record('protected_files', {name:hashlib.sha256((ARCHIVE/name).read_bytes()).hexdigest() for name in protected})
    old_schemas = list((BASELINE/'schemas').glob('*.schema.json'))
    assert len(old_schemas) == 8
    assert all(path.read_bytes() == (ARCHIVE/'schemas'/path.name).read_bytes() for path in old_schemas)
    record('eight_core_schemas', 'byte-identical')
    ledger = (ARCHIVE/'research/ai-usage-ledger.jsonl').read_bytes()
    for previous in ('4dbf484', '2ce1653'):
        assert ledger.startswith(git('show', previous+':research/ai-usage-ledger.jsonl'))
    rows = [json.loads(line) for line in ledger.splitlines()]
    new_rows = rows[-2:]
    for row in new_rows:
        assert hashlib.sha256(row['prompt_summary'].encode()).hexdigest() == row['prompt_sha256']
    record('ledger', {'rows':len(rows), 'prefix_preserved':True, 'new_prompt_hashes':True})
    evidence = ARCHIVE/'research/module-reports/M4-verification'
    identity = json.loads((evidence/'identity.json').read_text())
    for name, digest in identity['archive_sources_sha256'].items():
        assert hashlib.sha256((ARCHIVE/name).read_bytes()).hexdigest() == digest, name
    record('evidence_code_hashes', len(identity['archive_sources_sha256']))
    old_nodes = {line for line in (evidence/'old-nodes.log').read_text().splitlines() if '::' in line}
    new_nodes = {line for line in (evidence/'new-nodes.log').read_text().splitlines() if '::' in line}
    assert len(old_nodes)==339 and len(new_nodes)==745 and old_nodes<=new_nodes
    record('recorded_node_sets', {'original':339,'total':745,'added':406})
    zipped = list(evidence.rglob('*.gz'))
    for path in zipped:
        assert gzip.decompress(path.read_bytes())
    record('gzip_integrity', len(zipped))
    commands = [json.loads(line) for line in (evidence/'commands.jsonl').read_text().splitlines()]
    latest = {row['label']:row for row in commands}
    assert all(row['exit']==0 for row in latest.values())
    assert any(row['exit']!=0 for row in commands)
    record('command_history', {'rows':len(commands),'labels':len(latest),'initial_failures_preserved':True})
    env = {**os.environ, 'PYTHONPATH':str(ARCHIVE/'src')+os.pathsep+str(ARCHIVE),
           'PYTHONDONTWRITEBYTECODE':'1', 'HYPOTHESIS_STORAGE_DIRECTORY':str(ROOT/'hypothesis')}
    command=[str(PYTHON),'-m','pytest','tests/unit/test_ai_usage_ledger.py',
             'tests/unit/test_spec_lock.py','tests/unit/test_models.py','-q','-p','no:cacheprovider']
    result=subprocess.run(command,cwd=ARCHIVE,env=env,capture_output=True,text=True)
    (ROOT/'governance-tests.log').write_text(result.stdout+result.stderr)
    record('fresh_governance_tests', {'exit':result.returncode,'tail':result.stdout.splitlines()[-3:]})
    assert result.returncode==0
    status=git('status','--porcelain')
    assert not status
    record('audited_worktree', 'unchanged and clean')


if __name__=='__main__':
    try:
        verify()
    finally:
        (ROOT/'checks.json').write_text(json.dumps(RESULTS,indent=2)+'\n')
