"""Coordinator confirmation of independent findings, without production edits."""
import json
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).parent.resolve()
PY = '/Users/litmus/Documents/Contract Capsule/.worktrees/m4-view-compiler/.venv/bin/python'
scoped = Path('/private/tmp/m4-repair-rereview.XJYu96')
full = Path('/private/tmp/cc-m4-independent-aGz7nzgi')
jobs = [
    ('graph-denied-owner', scoped/'candidate', [PY,str(scoped/'reproduce_denied_owner.py')]),
    ('compiler-rank-and-revocation',full/'candidate',[PY,'-m','pytest',
     str(full/'probes/test_independent_boundaries.py')+'::test_fixed_class_priority_survives_valid_rank_order',
     str(full/'probes/test_independent_boundaries.py')+'::test_late_revocation_does_not_export_now_denied_identity',
     '-v','-p','no:cacheprovider']),
]
records=[]
for label,source,command in jobs:
    env={**os.environ,'PYTHONPATH':str(source/'src')+os.pathsep+str(source),
         'PYTHONDONTWRITEBYTECODE':'1','HYPOTHESIS_STORAGE_DIRECTORY':str(ROOT/'hypothesis')}
    result=subprocess.run(command,cwd=source,env=env,text=True,capture_output=True)
    (ROOT/(label+'.log')).write_text(result.stdout+result.stderr)
    record={'label':label,'command':command,'cwd':str(source),'exit':result.returncode,
            'tail':(result.stdout+result.stderr).splitlines()[-5:]}
    records.append(record)
    print(json.dumps(record),flush=True)
    assert result.returncode==1
(ROOT/'confirmation-results.json').write_text(json.dumps(records,indent=2)+'\n')
