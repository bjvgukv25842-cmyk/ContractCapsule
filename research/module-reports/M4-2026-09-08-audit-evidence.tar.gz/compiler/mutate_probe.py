"""Disposable runtime fault injection only; audited source files are not edited."""
from contextlib import ExitStack
from dataclasses import replace
from pathlib import Path
import sys
from unittest.mock import patch
import pytest

from contractcapsule.compile.session import Compilation
from contractcapsule.compile.evidence import NativeEvidenceResolver
from contractcapsule.models.view import TokenAccounting
from contractcapsule.resolve.eligibility import EligibilityResolver
from contractcapsule.resolve.graph import _Assembly

mode=sys.argv[1]
root=Path(__file__).parent
node={
    "permission":"test_permission_before_rank",
    "closure":"test_closure_preserved",
    "p0":"test_real_mandatory_overflow[P0_EXACT-P0_OVERFLOW]",
    "p1":"test_real_mandatory_overflow[P1_STRUCTURED-P1_OVERFLOW]",
    "replay":"test_exact_replay_rejects_changed_task",
    "evidence":"test_late_external_evidence_drift_blocks",
    "coverage":"test_admission_precedes_collective_coverage",
    "final-provider":"test_final_provider_payload_survives",
    "coverage-unadmitted-pool":"tests/integration/test_compile_view.py::test_unusable_root_provider_blocks_before_ranker[denied_member]",
    "provider-payload-truncation":"tests/integration/test_compile_view.py::test_required_whole_provider_cannot_drop_lower_class_member",
}[mode]

with ExitStack() as stack:
    if mode=="permission":
        stack.enter_context(patch.object(EligibilityResolver,"_atom_gates",lambda *args:None))
    elif mode=="closure":
        stack.enter_context(patch("contractcapsule.resolve.graph.dependency_closure",lambda selected,graph:set(selected)))
    elif mode in {"p0","p1"}:
        def unmetered(sections,counter,budget):
            return TokenAccounting(total=0,available=budget.available,sections={name:0 for name,_ in sections},boundary_adjustment=0)
        stack.enter_context(patch("contractcapsule.compile.session.account_tokens",unmetered))
    elif mode=="replay":
        original=Compilation.run
        def ignore_expectation(self,request):
            return original(self,request.model_copy(update={"expected_manifest_digest":None}))
        stack.enter_context(patch.object(Compilation,"run",ignore_expectation))
    elif mode=="evidence":
        original=NativeEvidenceResolver.resolve
        cache={}
        def stale_material(self,pub,atom,principal,task,as_of):
            key=(id(self),pub.capsule.control_manifest.content_digest,atom.atom_id)
            if key not in cache:
                cache[key]=original(self,pub,atom,principal,task,as_of)
            return cache[key]
        stack.enter_context(patch.object(NativeEvidenceResolver,"resolve",stale_material))
    elif mode=="coverage":
        stack.enter_context(patch.object(_Assembly,"roots",lambda *args:frozenset()))
    elif mode=="coverage-unadmitted-pool":
        original=_Assembly.inventory
        def include_rejected_members(self,admission):
            items=tuple(item.model_copy(update={"atom_ids":tuple(a.atom_id for a in item.published.capsule.semantic_payload.atoms)}) for item in admission.items)
            return original(self,admission.model_copy(update={"items":items}))
        stack.enter_context(patch.object(_Assembly,"inventory",include_rejected_members))
    elif mode=="provider-payload-truncation":
        original=_Assembly.roots
        def skip_lower_classes(self,task):
            members=original(self,task)
            return frozenset(a for a in members if self.atoms[a].compression_class in {"P0_EXACT","P1_STRUCTURED"})
        stack.enter_context(patch.object(_Assembly,"roots",skip_lower_classes))
    elif mode=="final-provider":
        original=Compilation._final_checks
        def lose_roots_guard(self,resolver,graph,request):
            return original(self,resolver,replace(graph,root_atom_ids=frozenset()),request)
        stack.enter_context(patch.object(Compilation,"_final_checks",lose_roots_guard))
    print("INJECTED",mode,"CHECKED_SOURCE",Compilation.__module__,flush=True)
    target=node if node.startswith("tests/") else str(root/"probes/test_independent_boundaries.py")+"::"+node
    sys.exit(pytest.main([target,"-v","-s","-p","no:cacheprovider"]))
