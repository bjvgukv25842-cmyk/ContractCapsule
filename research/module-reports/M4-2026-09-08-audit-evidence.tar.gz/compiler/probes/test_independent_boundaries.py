"""Independent black-box diagnostics against unmodified candidate imports."""
from dataclasses import replace
from unittest.mock import patch
import pytest

from contractcapsule.compile.budget import LocalTokenCounter
from contractcapsule.compile.evidence import NativeEvidenceResolver
from contractcapsule.compile.session import Compilation
from contractcapsule.models.view import ViewBudget, view_manifest_digest
from contractcapsule.resolve.rank import FTS5BM25Ranker
from tests.integration.test_compile_view import pipeline, selection
from tests.m4_helpers import M4Fixture
from tests.unit.test_eligibility import task_context

@pytest.fixture(scope="module")
def counter():
    return LocalTokenCounter("independent-audit")

def test_fixed_class_priority_survives_valid_rank_order(tmp_path, counter):
    fixture = M4Fixture.create(tmp_path)
    pub = fixture.publish(atoms=(
        {"atom_id":"p2", "statement":"token required evidence. " * 70, "compression_class":"P2_EVIDENCE"},
        {"atom_id":"p3", "statement":"token background history. " * 70, "compression_class":"P3_SUMMARY"},
    ))
    compiler, request = pipeline(fixture, (pub,), counter)
    original = FTS5BM25Ranker.rank_atoms
    # Both real lexical matches are returned unchanged; only rank order varies.
    class ReverseRanker:
        version = "1.0.0"
        config_digest = "sha256:" + "1"*64
        def rank_atoms(self, atoms, task):
            return list(reversed(original(FTS5BM25Ranker(), atoms, task)))
    full = compiler.compile_view(request)
    assert full.validation.valid and selection(full) == {"p2","p3"}
    chosen_budget = None
    for budget in range(400, full.manifest.tokens.total, 50):
        constrained = request.model_copy(update={"budget":ViewBudget(model_input_tokens=budget)})
        native = compiler.compile_view(constrained)
        alternate = replace(compiler, ranker=ReverseRanker()).compile_view(constrained)
        if native.validation.valid and alternate.validation.valid and selection(native)=={"p2"} and selection(alternate)=={"p3"}:
            chosen_budget=budget
            print("PRIORITY_OBSERVATION", budget, sorted(selection(native)), sorted(selection(alternate)))
            break
    assert chosen_budget is not None, "diagnostic setup must reach competing budget groups"
    assert selection(alternate) == {"p2"}, "P2 must precede optional P3 regardless of relevance-ranker order"

def test_late_revocation_does_not_export_now_denied_identity(tmp_path,counter):
    fixture=M4Fixture.create(tmp_path)
    pub=fixture.publish(capsule_id="com.private.identifier", atoms=({"atom_id":"private-identity", "compression_class":"P0_EXACT"},))
    compiler,request=pipeline(fixture,(pub,),counter)
    original=NativeEvidenceResolver.resolve
    calls=0
    def revoke_after_read(self,*args):
        nonlocal calls
        result=original(self,*args)
        calls+=1
        if calls==2:
            object.__setattr__(self.authorizer,"grants",())
        return result
    with patch.object(NativeEvidenceResolver,"resolve",revoke_after_read):
        view=compiler.compile_view(request)
    assert calls==2 and not view.validation.valid and view.content==""
    print("REVOCATION_OBSERVATION",view.validation.blockers,view.manifest.model_dump_json())
    assert "private-identity" not in view.model_dump_json()
    assert "com.private.identifier" not in view.model_dump_json()

def test_permission_before_rank(tmp_path,counter):
    fixture=M4Fixture.create(tmp_path)
    pub=fixture.publish(atoms=(
        {"atom_id":"allowed","compression_class":"P0_EXACT"},
        {"atom_id":"denied","statement":"token "*500,"scope":("path:other/**",)},
    ))
    compiler,request=pipeline(fixture,(pub,),counter)
    original=FTS5BM25Ranker.rank_atoms
    seen=[]
    def record(self,atoms,task):
        seen.extend(a.atom_id for a in atoms)
        return original(self,atoms,task)
    with patch.object(FTS5BM25Ranker,"rank_atoms",record):
        view=compiler.compile_view(request)
    assert view.validation.valid
    assert seen==["allowed"]
    assert "denied" not in view.model_dump_json()

def test_closure_preserved(tmp_path,counter):
    fixture=M4Fixture.create(tmp_path)
    def amend(raw):
        raw["semantic_payload"]["atoms"][0]["requires_atoms"]=["dependency"]
    pub=fixture.publish(atoms=(
        {"atom_id":"hard","compression_class":"P0_EXACT"},
        {"atom_id":"dependency","compression_class":"P3_SUMMARY"},
    ),amend=amend)
    compiler,request=pipeline(fixture,(pub,),counter)
    view=compiler.compile_view(request)
    assert view.validation.valid
    assert selection(view)=={"hard","dependency"}

@pytest.mark.parametrize("kind,blocker",[("P0_EXACT","P0_OVERFLOW"),("P1_STRUCTURED","P1_OVERFLOW")])
def test_real_mandatory_overflow(tmp_path,counter,kind,blocker):
    fixture=M4Fixture.create(tmp_path)
    pub=fixture.publish(atoms=({"statement":"token "*1200,"compression_class":kind},))
    compiler,request=pipeline(fixture,(pub,),counter)
    positive=compiler.compile_view(request)
    assert positive.validation.valid
    small=request.model_copy(update={"budget":ViewBudget(model_input_tokens=500)})
    view=compiler.compile_view(small)
    assert view.content==""
    assert view.validation.blockers==(blocker,)
    assert view.manifest.tokens.total>500

def test_exact_replay_rejects_changed_task(tmp_path,counter):
    fixture=M4Fixture.create(tmp_path)
    compiler,request=pipeline(fixture,(fixture.publish(atoms=({"compression_class":"P0_EXACT"},)),),counter)
    first=compiler.compile_view(request)
    assert first.validation.valid
    old_digest=view_manifest_digest(first.manifest)
    good=compiler.compile_view(request.model_copy(update={"expected_manifest_digest":old_digest}))
    assert good==first
    bad=compiler.compile_view(request.model_copy(update={"task":task_context(text="changed"),"expected_manifest_digest":old_digest}))
    assert bad.validation.blockers==("REPLAY_MISMATCH",) and not bad.content

def test_admission_precedes_collective_coverage(tmp_path,counter):
    fixture=M4Fixture.create(tmp_path)
    a=fixture.publish(capsule_id="com.example.auth",provides=("auth/v2",),atoms=({"atom_id":"auth"},))
    b=fixture.publish(capsule_id="com.example.audit",provides=("audit/v1",),atoms=({"atom_id":"audit-denied","scope":("path:other/**",)},))
    compiler,request=pipeline(fixture,(a,b),counter)
    request=request.model_copy(update={"task":task_context(required_interfaces=("auth/v2","audit/v1"))})
    with patch.object(FTS5BM25Ranker,"rank_atoms",side_effect=AssertionError("must not reach ranking")) as rank:
        view=compiler.compile_view(request)
    assert view.validation.blockers==("MISSING_INTERFACE",)
    assert rank.call_count==0 and not view.content
    assert "audit-denied" not in view.model_dump_json()

def test_final_provider_payload_survives(tmp_path,counter):
    fixture=M4Fixture.create(tmp_path)
    pub=fixture.publish(provides=("auth/v2",),atoms=(
        {"atom_id":"main","statement":"token"},
        {"atom_id":"sibling","statement":"background","compression_class":"P3_SUMMARY"},
    ))
    compiler,request=pipeline(fixture,(pub,),counter)
    request=request.model_copy(update={"task":task_context(required_interfaces=("auth/v2",))})
    original=Compilation._select
    def lose_provider(self,*args):
        original(self,*args)
        self.selected.discard("sibling")
        self.content,self.tokens=self._render(self.selected)
    with patch.object(Compilation,"_select",lose_provider):
        view=compiler.compile_view(request)
    assert view.validation.blockers==("FINAL_PRESERVATION_FAILED",) and not view.content

def test_late_evidence_drift_blocks(tmp_path,counter):
    fixture=M4Fixture.create(tmp_path)
    pub=fixture.publish(atoms=({"compression_class":"P0_EXACT"},))
    compiler,request=pipeline(fixture,(pub,),counter)
    original=FTS5BM25Ranker.rank_atoms
    def drift(self,atoms,task):
        result=original(self,atoms,task)
        path=fixture.harness.cas.object_path(pub.capsule.evidence_plane.records[0].content_digest)
        path.chmod(0o600)
        path.write_bytes(b"corrupted evidence")
        return result
    with patch.object(FTS5BM25Ranker,"rank_atoms",drift):
        view=compiler.compile_view(request)
    assert not view.validation.valid and not view.content
    assert not view.evidence_handles

def test_late_external_evidence_drift_blocks(tmp_path,counter):
    from tests.unit.test_evidence_handles import native_publication
    from contractcapsule.compile.compiler import ViewCompiler
    from contractcapsule.compile.renderers import NeutralViewRenderer
    from contractcapsule.models.view import CompileRequest
    from tests.unit.test_eligibility import AS_OF, READER
    pub,task,evidence,path=native_publication(tmp_path,"EXTERNAL_IMMUTABLE")
    compiler=ViewCompiler(evidence.registry,evidence.authorizer,evidence.freshness,FTS5BM25Ranker(),counter,evidence,NeutralViewRenderer())
    request=CompileRequest(capsules=(pub,),task=task,principal=READER,budget=ViewBudget(model_input_tokens=10000),as_of=AS_OF,model_id=counter.model_id,tokenizer_profile=counter.profile)
    original=FTS5BM25Ranker.rank_atoms
    def drift(self,atoms,task):
        result=original(self,atoms,task)
        path.write_bytes(b"# Changed after ranking\n")
        return result
    with patch.object(FTS5BM25Ranker,"rank_atoms",drift):
        view=compiler.compile_view(request)
    assert not view.validation.valid and not view.content
    assert not view.evidence_handles
