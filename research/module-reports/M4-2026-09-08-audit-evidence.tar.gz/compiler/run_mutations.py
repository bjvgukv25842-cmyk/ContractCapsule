from run_audit import ROOT,PY,run

results=[]
baseline=run("independent-safety-baseline",[PY,"-m","pytest",str(ROOT/"probes/test_independent_boundaries.py"),"-v","-k","not fixed_class_priority and not late_revocation_does_not_export"])
assert baseline.returncode==0
for mode in ["permission","closure","p0","p1","replay","evidence","coverage","final-provider"]:
    result=run("mutation-"+mode,[PY,str(ROOT/"mutate_probe.py"),mode])
    detected=result.returncode==1 and "AssertionError" in result.stdout and "1 failed" in result.stdout and "ERROR collecting" not in result.stdout
    results.append((mode,detected))
print("FAULT_DETECTION",results,flush=True)
assert all(passed for _,passed in results),results
