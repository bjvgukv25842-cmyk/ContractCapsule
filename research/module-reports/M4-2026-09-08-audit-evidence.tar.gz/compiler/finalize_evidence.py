"""Read-only final identity and provenance assertions; small JSON evidence output."""
import hashlib
import json
from pathlib import Path
import subprocess
from run_audit import ROOT,SOURCE,BASELINE,run,PY

repo=Path("/Users/litmus/Documents/Contract Capsule/.worktrees/m4-view-compiler")
target="2ce16535ece97733404e91715bb2b7586b54de20"
gov=ROOT/"governance"
records=subprocess.check_output(["git","ls-tree","-r","-z",target],cwd=repo).split(b"\0")
checked=0
for record in records:
    if not record:
        continue
    info,path=record.split(b"\t",1)
    _,kind,expected=info.split()
    assert kind==b"blob"
    data=(SOURCE/path.decode()).read_bytes()
    actual=hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()
    assert actual==expected.decode(),path
    checked+=1
identity=json.loads((gov/"research/module-reports/M4-verification/identity.json").read_text())
for path,digest in identity["archive_sources_sha256"].items():
    assert hashlib.sha256((repo/path).read_bytes()).hexdigest()==digest,path
rows=[json.loads(line) for line in (gov/"research/ai-usage-ledger.jsonl").read_text().splitlines()]
verified_prompts=0
for row in rows:
    if row.get("prompt_digest_basis")=="exact UTF-8 prompt_summary":
        assert hashlib.sha256(row["prompt_summary"].encode()).hexdigest()==row["prompt_sha256"]
        verified_prompts+=1
tech_ledger=(SOURCE/"research/ai-usage-ledger.jsonl").read_bytes()
baseline_ledger=(BASELINE/"research/ai-usage-ledger.jsonl").read_bytes()
assert tech_ledger.startswith(baseline_ledger)
assert (gov/"research/ai-usage-ledger.jsonl").read_bytes().startswith(tech_ledger)
changed=subprocess.check_output(["git","diff","--name-only",target,"cd6cfcf3c7385820862a341db01a6d440509f3bd"],cwd=repo,text=True).splitlines()
assert len(changed)==39 and all(p.startswith("research/") for p in changed)
statuses={}
for location in [repo,Path("/Users/litmus/Documents/Contract Capsule")]:
    head=subprocess.check_output(["git","rev-parse","HEAD"],cwd=location,text=True).strip()
    status=subprocess.check_output(["git","status","--porcelain=v1"],cwd=location,text=True)
    statuses[str(location)]={"HEAD":head,"status":status}
    assert not status
report={"technical_sha":target,"governance_sha":"cd6cfcf3c7385820862a341db01a6d440509f3bd","approved_M3":"4dbf4849c6e125d1cb5ac8d813e4aeb5dc75694d","physical_archive":str(SOURCE),"all_archived_git_blobs_unchanged":checked,"recorded94_live_artifacts_match":len(identity["archive_sources_sha256"]),"governance_research_only_changed_paths":len(changed),"ledger_rows":len(rows),"verified_exact_summary_prompt_digests":verified_prompts,"ledger_prefixes_preserved":True,"states":statuses,"model_id":"unavailable:not-exposed-by-session-metadata","token_usage":"unavailable:not-exposed-by-session-metadata","provider_cost":"unavailable:not-exposed-by-session-metadata"}
(ROOT/"final-checks.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps(report,indent=2),flush=True)
run("final-independent-boundaries",[PY,"-m","pytest",str(ROOT/"probes/test_independent_boundaries.py"),"-v","-s"])
