"""Manifest explicitly scoped evidence files, excluding source/caches/test keys."""
import hashlib
import json
from pathlib import Path

root=Path(__file__).parent.resolve()
names=["REPORT.md","run_audit.py","supplemental.py","finalize_evidence.py","run_mutations.py","mutate_probe.py","make_export_manifest.py","probes/test_independent_boundaries.py","commands.jsonl","node-retention.json","final-checks.json"]
names+=sorted(str(p.relative_to(root)) for p in (root/"logs").glob("*.log"))
artifacts={}
for name in names:
    content=(root/name).read_bytes()
    artifacts[name]={"sha256":hashlib.sha256(content).hexdigest(),"bytes":len(content)}
payload={"root":str(root),"verdict":"REQUEST CHANGES","technical_sha":"2ce16535ece97733404e91715bb2b7586b54de20","governance_sha":"cd6cfcf3c7385820862a341db01a6d440509f3bd","artifacts":artifacts}
(root/"artifact-manifest.json").write_text(json.dumps(payload,indent=2)+"\n")
print("EXPORT_FILES",len(artifacts),"TOTAL_BYTES",sum(item["bytes"] for item in artifacts.values()))
print("REPORT_SHA256",artifacts["REPORT.md"]["sha256"])
