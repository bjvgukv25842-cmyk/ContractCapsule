"""Independent read-only M4 verification on exact clean Git archives."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).parent.resolve()
SOURCE = ROOT / "candidate"
BASELINE = ROOT / "baseline"
VENV = Path("/Users/litmus/Documents/Contract Capsule/.worktrees/m4-view-compiler/.venv")
PY = str(VENV / "bin/python")

def environment(source):
    return {**os.environ, "PYTHONPATH":str(source / "src") + os.pathsep + str(source),
            "PYTHONDONTWRITEBYTECODE":"1", "UV_OFFLINE":"1", "UV_NO_SYNC":"1",
            "UV_PROJECT_ENVIRONMENT":str(VENV), "UV_CACHE_DIR":str(ROOT / "cache/uv"),
            "HYPOTHESIS_STORAGE_DIRECTORY":str(ROOT / "cache/hypothesis"),
            "MYPY_CACHE_DIR":str(ROOT / "cache/mypy"), "RUFF_CACHE_DIR":str(ROOT / "cache/ruff"),
            "PYTEST_ADDOPTS":"-p no:cacheprovider", "PATH":str(VENV / "bin") + os.pathsep + os.environ["PATH"]}

def run(label, command, source=SOURCE):
    result = subprocess.run(command, cwd=source, env=environment(source), text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (ROOT / "logs" / (label + ".log")).write_text(result.stdout)
    record = {"label":label, "command":command, "cwd":str(source), "exit_code":result.returncode,
              "log_sha256":hashlib.sha256(result.stdout.encode()).hexdigest(), "tail":result.stdout.splitlines()[-5:]}
    with (ROOT / "commands.jsonl").open("a") as out:
        out.write(json.dumps(record) + "\n")
    print(json.dumps(record), flush=True)
    return result

if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "core"
    if mode == "core":
        run("imports", [PY, "-c", "from pathlib import Path; import contractcapsule, contractcapsule.compile.compiler as c, tests.m4_helpers as h; print(contractcapsule.__file__, c.__file__, h.__file__); assert all(str(Path(p).resolve()).startswith('/private/tmp/cc-m4-independent-aGz7nzgi/candidate/') for p in [contractcapsule.__file__,c.__file__,h.__file__])"])
        checks = [
            ("frozen-exact", ["uv", "run", "pytest", "tests/unit/test_eligibility.py", "tests/unit/test_dependency_closure.py", "tests/unit/test_budget.py", "tests/integration/test_compile_view.py", "-v"]),
            ("full", [PY, "-m", "pytest", "-q", "-ra"]),
            ("formal", [PY, "-m", "pytest", "tests/fixtures/formal_cases", "-v"]),
            ("ruff", [PY, "-m", "ruff", "check", "."]),
            ("ruff-no-ignore", [PY, "-m", "ruff", "check", ".", "--no-respect-gitignore", "--no-cache"]),
            ("complexity", [PY, "-m", "ruff", "check", "src/contractcapsule", "tests", "--select", "C901,PLR0911,PLR0912,PLR0915"]),
            ("complexity-no-ignore", [PY, "-m", "ruff", "check", "src/contractcapsule", "tests", "--select", "C901,PLR0911,PLR0912,PLR0915", "--no-respect-gitignore", "--no-cache"]),
            ("mypy", [PY, "-m", "mypy", "."]),
            ("offline-lock", ["uv", "lock", "--check", "--offline"]),
        ]
        for name, args in checks:
            run(name, args)
        old = run("baseline-nodes", [PY, "-m", "pytest", "--collect-only", "-q"], BASELINE)
        new = run("candidate-nodes", [PY, "-m", "pytest", "--collect-only", "-q"])
        old_nodes = {line for line in old.stdout.splitlines() if "::" in line}
        new_nodes = {line for line in new.stdout.splitlines() if "::" in line}
        result = {"old_nodes":len(old_nodes), "new_nodes":len(new_nodes), "missing":sorted(old_nodes-new_nodes)}
        (ROOT / "node-retention.json").write_text(json.dumps(result, indent=2))
        print(json.dumps(result), flush=True)
    elif mode == "inventory":
        for source, label in [(SOURCE,"candidate"), (Path("/Users/litmus/Documents/Contract Capsule/.worktrees/m4-view-compiler"),"worktree")]:
            expected = {str(p.resolve()) for area in ["src/contractcapsule","tests"] for p in (source/area).rglob("*.py")}
            for no_ignore in [False,True]:
                result = run("inventory-"+label+str(no_ignore), [PY,"-m","ruff","check","src/contractcapsule","tests","--show-files","--no-cache"]+(["--no-respect-gitignore"] if no_ignore else []),source)
                found={str(Path(p).resolve()) for p in result.stdout.splitlines() if p.endswith(".py")}
                assert expected == found, (expected-found,found-expected)
                print("INVENTORY",label,no_ignore,len(found), flush=True)
