"""Artifact and governance checks performed independently of recorded claims."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import zipfile
from run_audit import ROOT,SOURCE,BASELINE,PY,run,environment

governance=ROOT/"governance"
repo=Path("/Users/litmus/Documents/Contract Capsule/.worktrees/m4-view-compiler")
identity=json.loads((governance/"research/module-reports/M4-verification/identity.json").read_text())
for path,digest in identity["archive_sources_sha256"].items():
    assert hashlib.sha256((SOURCE/path).read_bytes()).hexdigest()==digest,path
    assert (SOURCE/path).read_bytes()==(governance/path).read_bytes(),path
print("INDEPENDENT_IDENTITY_MATCH",len(identity["archive_sources_sha256"]),flush=True)
protected=["docs/spec/CCS-2.1.md","docs/superpowers/plans/2026-07-30-contract-capsule-fse-2027-execution-plan.md","docs/protocol/formal-model.md","src/contractcapsule/formal.py"]
protected += [str(p.relative_to(BASELINE)) for p in (BASELINE/"schemas").glob("*.schema.json")]
protected += [str(p.relative_to(BASELINE)) for p in (BASELINE/"tests/fixtures/formal_cases").rglob("*") if p.is_file()]
for path in protected:
    assert (BASELINE/path).read_bytes()==(SOURCE/path).read_bytes()==(governance/path).read_bytes(),path
print("PROTECTED_BYTES",len(protected),flush=True)
old=(BASELINE/"research/ai-usage-ledger.jsonl").read_bytes()
technical=(SOURCE/"research/ai-usage-ledger.jsonl").read_bytes()
current=(governance/"research/ai-usage-ledger.jsonl").read_bytes()
assert technical.startswith(old) and current.startswith(technical)
rows=[json.loads(row) for row in current.splitlines()]
print("LEDGER_ROWS",len(rows),"APPEND_ONLY",flush=True)
for path in (governance/"research/module-reports/M4-verification").rglob("*.gz"):
    gzip.decompress(path.read_bytes())
print("GZIP_INTEGRITY",len(list((governance/"research/module-reports/M4-verification").rglob("*.gz"))),flush=True)
result=run("governance-diff",["git","diff","--name-only","2ce16535ece97733404e91715bb2b7586b54de20","cd6cfcf3c7385820862a341db01a6d440509f3bd"],repo)
assert all(path.startswith("research/") for path in result.stdout.splitlines())
run("whitespace",["git","diff","--check","4dbf4849c6e125d1cb5ac8d813e4aeb5dc75694d","cd6cfcf3c7385820862a341db01a6d440509f3bd"],repo)
run("governance-tests",[PY,"-m","pytest","tests/unit/test_ai_usage_ledger.py","tests/unit/test_spec_lock.py","tests/unit/test_models.py","-q"],governance)
run("schema-generation",[PY,"-m","contractcapsule.compile.schema",str(ROOT/"view-manifest.schema.json")])
assert (ROOT/"view-manifest.schema.json").read_bytes()==(SOURCE/"schemas/view-manifest.schema.json").read_bytes()
run("schema-core-regeneration",[PY,"-c","import json; from pathlib import Path; from contractcapsule.models.schema import schema_documents; schemas=schema_documents(); assert len(schemas)==8; assert all(json.loads((Path('schemas')/n).read_text())==doc for n,doc in schemas.items()); print('all eight core schemas regenerate identically as structured JSON')"])
run("offline-build",["uv","build","--offline","--out-dir",str(ROOT/"dist")])
dist=ROOT/"dist"
if list(dist.glob("*.whl")):
    package=ROOT/"wheel-package"
    package.mkdir(exist_ok=True)
    with zipfile.ZipFile(next(dist.glob("*.whl"))) as wheel:
        wheel.extractall(package)
    env=environment(package)
    env["PYTHONPATH"]=str(package)
    cmd=[PY,"-c","from pathlib import Path; import contractcapsule.compile.compiler as compiler; from contractcapsule.compile.budget import LocalTokenCounter; assert str(Path(compiler.__file__).resolve()).startswith('/private/tmp/cc-m4-independent-aGz7nzgi/wheel-package/'); counter=LocalTokenCounter('packaged-audit'); assert counter.count('hello world')==2; print('PACKAGED_IMPORT',compiler.__file__); print('TOKENS',counter.count('hello world')); print('PROFILE',counter.profile); print('RESOURCES_OK')"]
    result=subprocess.run(cmd,cwd=package,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (ROOT/"logs/wheel-smoke.log").write_text(result.stdout)
    print("WHEEL_SMOKE",result.returncode,result.stdout,flush=True)
else:
    print("WHEEL_SMOKE_NOT_RUN_BUILD_FAILED",flush=True)
