"""Record actual remediation commands without altering their output bytes."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).parent.resolve()
WORKTREE = Path('/Users/litmus/Documents/Contract Capsule/.worktrees/m4-exit-remediation')
label, *command = sys.argv[1:]
target = ROOT/(label+'.log')
assert not target.exists(), 'do not overwrite prior command evidence'
result = subprocess.run(command,cwd=WORKTREE,env={**os.environ,'UV_OFFLINE':'1'},
                        stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
target.write_bytes(result.stdout)
record={'label':label,'command':command,'cwd':str(WORKTREE),'exit':result.returncode,
        'sha256':hashlib.sha256(result.stdout).hexdigest()}
with (ROOT/'commands.jsonl').open('a') as stream:
    stream.write(json.dumps(record)+'\n')
print(result.stdout.decode(errors='replace'))
print(json.dumps(record))
raise SystemExit(result.returncode)
