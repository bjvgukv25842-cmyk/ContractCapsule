"""Controller final inventories, original-test retention and packaged-resource checks."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import zipfile

ROOT=Path(__file__).parent.resolve()
TREE=Path('/Users/litmus/Documents/Contract Capsule/.worktrees/m4-exit-remediation')
BASE=Path('/Users/litmus/Documents/Contract Capsule/.worktrees/m4-view-compiler')
PY=str(TREE/'.venv/bin/python')
checks={}

def run(label, command, cwd=TREE):
    env={**os.environ,'PYTHONPATH':str(cwd/'src')+os.pathsep+str(cwd),
         'PYTHONDONTWRITEBYTECODE':'1','UV_OFFLINE':'1'}
    result=subprocess.run(command,cwd=cwd,env=env,capture_output=True,text=True)
    (ROOT/(label+'.log')).write_text(result.stdout+result.stderr)
    checks[label]={'command':command,'cwd':str(cwd),'exit':result.returncode}
    assert result.returncode==0,(label,result.stdout,result.stderr)
    return result.stdout

old=run('old745-nodes',[PY,'-m','pytest','--collect-only','-q','-p','no:cacheprovider'],BASE)
new=run('new763-nodes',[PY,'-m','pytest','--collect-only','-q','-p','no:cacheprovider'])
old_nodes={line for line in old.splitlines() if '::' in line}
new_nodes={line for line in new.splitlines() if '::' in line}
assert len(old_nodes)==745 and len(new_nodes)==763 and old_nodes<=new_nodes
checks['node_counts']={'old':len(old_nodes),'new':len(new_nodes),'missing':sorted(old_nodes-new_nodes)}
expected={str(path.resolve()) for area in ('src/contractcapsule','tests') for path in (TREE/area).rglob('*.py')}
for mode in (False,True):
    found=run('inventory-'+str(mode),[PY,'-m','ruff','check','src/contractcapsule','tests','--show-files','--no-cache']+(['--no-respect-gitignore'] if mode else []))
    assert {str(Path(line).resolve()) for line in found.splitlines()}==expected
checks['discovered_python_files']=len(expected)
protected=['docs/spec/CCS-2.1.md','docs/superpowers/plans/2026-07-30-contract-capsule-fse-2027-execution-plan.md',
           'src/contractcapsule/formal.py','docs/protocol/formal-model.md','pyproject.toml','uv.lock']
protected += [str(path.relative_to(BASE)) for area in ('schemas','tests') for path in (BASE/area).rglob('*')
              if path.is_file() and '__pycache__' not in path.parts]
assert all((TREE/path).read_bytes()==(BASE/path).read_bytes() for path in protected)
checks['protected_files_identical']=len(protected)
checks['source_hashes']={str(path.relative_to(TREE)):hashlib.sha256(path.read_bytes()).hexdigest()
                        for area in ('src','tests','schemas') for path in (TREE/area).rglob('*')
                        if path.is_file() and '__pycache__' not in path.parts}
wheel=ROOT/'wheel'
with zipfile.ZipFile(ROOT/'dist/contractcapsule-0.1.0-py3-none-any.whl') as package:
    package.extractall(wheel)
smoke=("import sys;sys.path.insert(0,"+repr(str(wheel))+"); "
       "import contractcapsule.compile.compiler as c; "
       "from contractcapsule.compile.budget import LocalTokenCounter; "
       "assert c.__file__.startswith("+repr(str(wheel))+"); "
       "assert LocalTokenCounter('offline-package').count('hello world')==2; "
       "print('packaged compiler import and offline tokenizer PASS')")
run('wheel-smoke',[PY,'-c',smoke])
checks['technical_commit']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=TREE,text=True).strip()
(ROOT/'artifact-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps({key:value for key,value in checks.items() if key!='source_hashes'},indent=2))
