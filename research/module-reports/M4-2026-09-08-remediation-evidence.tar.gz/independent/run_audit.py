"""Independent exact-commit M4 repair reaudit, no source or environment writes."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).parent.resolve()
SOURCE=ROOT/"candidate"
BEFORE=ROOT/"before"
M3=ROOT/"m3"
WORKTREE=Path("/Users/litmus/Documents/Contract Capsule/.worktrees/m4-exit-remediation")
VENV=WORKTREE/".venv"
PY=str(VENV/"bin/python")
SHA="bb1d56daecbc31240b5ea1371378c50e63dd9c4b"

def environment(source):
    return {**os.environ,"PYTHONPATH":str(source/"src")+os.pathsep+str(source),"PYTHONDONTWRITEBYTECODE":"1","UV_OFFLINE":"1","UV_NO_SYNC":"1","UV_PROJECT_ENVIRONMENT":str(VENV),"UV_CACHE_DIR":str(ROOT/"cache/uv"),"HYPOTHESIS_STORAGE_DIRECTORY":str(ROOT/"cache/hypothesis"),"MYPY_CACHE_DIR":str(ROOT/"cache/mypy"),"RUFF_CACHE_DIR":str(ROOT/"cache/ruff"),"PYTEST_ADDOPTS":"-p no:cacheprovider","PATH":str(VENV/"bin")+os.pathsep+os.environ["PATH"]}

def run(label,args,source=SOURCE):
    result=subprocess.run(args,cwd=source,env=environment(source),text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    path=ROOT/"logs"/(label+".log")
    assert not path.exists(),"never overwrite completed evidence"
    path.write_text(result.stdout)
    entry={"label":label,"argv":args,"cwd":str(source),"exit":result.returncode,"sha256":hashlib.sha256(result.stdout.encode()).hexdigest(),"tail":result.stdout.splitlines()[-5:]}
    with (ROOT/"commands.jsonl").open("a") as out:
        out.write(json.dumps(entry)+"\n")
    print(json.dumps(entry),flush=True)
    return result

if __name__=="__main__":
    run("imports",[PY,"-c","from pathlib import Path; import contractcapsule.compile.compiler as c, tests.m4_helpers as h; print(c.__file__); print(h.__file__); assert all(str(Path(p).resolve()).startswith('/private/tmp/cc-m4-repair-independent-sABc2vmV/candidate/') for p in (c.__file__,h.__file__))"])
    checks=[
        ("new-persistent",[PY,"-m","pytest","tests/unit/test_graph_owner_admission.py","tests/integration/test_m4_exit_repairs.py","-v"]),
        ("frozen-exact",["uv","run","pytest","tests/unit/test_eligibility.py","tests/unit/test_dependency_closure.py","tests/unit/test_budget.py","tests/integration/test_compile_view.py","-v"]),
        ("full",[PY,"-m","pytest","-q","-ra"]),
        ("formal",[PY,"-m","pytest","tests/fixtures/formal_cases","-v"]),
        ("ruff",[PY,"-m","ruff","check","."]),
        ("ruff-no-ignore",[PY,"-m","ruff","check",".","--no-respect-gitignore","--no-cache"]),
        ("complexity",[PY,"-m","ruff","check","src/contractcapsule","tests","--select","C901,PLR0911,PLR0912,PLR0915"]),
        ("complexity-no-ignore",[PY,"-m","ruff","check","src/contractcapsule","tests","--select","C901,PLR0911,PLR0912,PLR0915","--no-respect-gitignore","--no-cache"]),
        ("mypy",[PY,"-m","mypy","."]),
        ("offline-lock",["uv","lock","--check","--offline"]),
    ]
    for label,args in checks:
        run(label,args)
    populations={}
    for label,source in [("m3",M3),("before",BEFORE),("candidate",SOURCE)]:
        result=run(label+"-nodes",[PY,"-m","pytest","--collect-only","-q"],source)
        populations[label]={line for line in result.stdout.splitlines() if "::" in line}
    assert len(populations["m3"])==339 and len(populations["before"])==745
    assert populations["m3"]<=populations["before"]<=populations["candidate"]
    report={"counts":{k:len(v) for k,v in populations.items()},"missing_m3":sorted(populations["m3"]-populations["candidate"]),"missing_before":sorted(populations["before"]-populations["candidate"])}
    (ROOT/"node-retention.json").write_text(json.dumps(report,indent=2)+"\n")
    print("RETENTION",report,flush=True)
