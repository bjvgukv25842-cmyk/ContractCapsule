"""Read-only integrity, inventory, build and exact-method mutation checks."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile
from run_audit import ROOT,SOURCE,BEFORE,M3,WORKTREE,PY,SHA,run,environment

def git(*args):
    return subprocess.check_output(["git",*args],cwd=WORKTREE,text=True)

checks={"technical_commit":SHA,"pre_repair":"44585274b5fd639df6b76ea85825a007b01b1c48"}
changes=git("diff","--name-only",checks["pre_repair"],SHA).splitlines()
assert set(changes)=={"src/contractcapsule/resolve/graph.py","src/contractcapsule/compile/session.py","src/contractcapsule/compile/manifest.py","tests/unit/test_graph_owner_admission.py","tests/integration/test_m4_exit_repairs.py"}
checks["scoped_changes"]=changes
protected=["docs/spec/CCS-2.1.md","docs/superpowers/plans/2026-07-30-contract-capsule-fse-2027-execution-plan.md","docs/protocol/formal-model.md","src/contractcapsule/formal.py","pyproject.toml","uv.lock"]
protected += [str(p.relative_to(BEFORE)) for p in (BEFORE/"schemas").glob("*.json")]
protected += [str(p.relative_to(BEFORE)) for p in (BEFORE/"src/contractcapsule/models").glob("*.py")]
for name in protected:
    assert (SOURCE/name).read_bytes()==(BEFORE/name).read_bytes(),name
for path in (M3/"schemas").glob("*.json"):
    assert path.read_bytes()==(SOURCE/"schemas"/path.name).read_bytes()
checks["protected_files"]=len(protected)
checks["core_schema_bytes_unchanged"]=8
for name,expected in [("docs/spec/CCS-2.1.md","aaddaa8def8df1ef2efbe4f9487de0ba86a60ae5aed8955ca76f5e070fa01e5c"),("docs/superpowers/plans/2026-07-30-contract-capsule-fse-2027-execution-plan.md","7c1feebb36776c09de5c0ba5462540072374b9902d8e04d405585a8efb8659c0")]:
    assert hashlib.sha256((SOURCE/name).read_bytes()).hexdigest()==expected
checks["frozen_hashes_match"]=True
for root,label in [(SOURCE,"archive"),(WORKTREE,"worktree")]:
    expected={str(p.resolve()) for area in ("src/contractcapsule","tests") for p in (root/area).rglob("*.py")}
    for extra,suffix in [([],"ordinary"),(["--no-respect-gitignore"],"no-ignore")]:
        result=run("inventory-"+label+"-"+suffix,[PY,"-m","ruff","check","src/contractcapsule","tests","--show-files","--no-cache",*extra],root)
        actual={str(Path(line).resolve()) for line in result.stdout.splitlines() if line.endswith(".py")}
        assert actual==expected
    checks["inventory_"+label]=len(expected)
run("schema-regeneration",[PY,"-m","contractcapsule.compile.schema",str(ROOT/"generated-schema.json")])
assert (ROOT/"generated-schema.json").read_bytes()==(SOURCE/"schemas/view-manifest.schema.json").read_bytes()
run("core-schema-regeneration",[PY,"-c","import json; from pathlib import Path; from contractcapsule.models.schema import schema_documents; docs=schema_documents(); assert len(docs)==8; assert all(json.loads((Path('schemas')/name).read_text())==value for name,value in docs.items()); print('8 core schemas regenerate identically')"])
run("diff-whitespace",["git","diff","--check",checks["pre_repair"],SHA],WORKTREE)
run("offline-build",["uv","build","--offline","--out-dir",str(ROOT/"dist")])
wheel=next((ROOT/"dist").glob("*.whl"))
with zipfile.ZipFile(wheel) as archive:
    archive.extractall(ROOT/"wheel")
wheel_environment=environment(SOURCE)
wheel_environment["PYTHONPATH"]=str(ROOT/"wheel")
result=subprocess.run([PY,"-c","from pathlib import Path; import contractcapsule.compile.compiler as c; from contractcapsule.compile.budget import LocalTokenCounter; assert '/cc-m4-repair-independent-sABc2vmV/wheel/' in str(Path(c.__file__).resolve()); assert LocalTokenCounter('audit').count('hello world')==2; print(c.__file__); print('packaged offline tokenizer passed')"],cwd=ROOT/"wheel",env=wheel_environment,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(ROOT/"logs/wheel-smoke.log").write_text(result.stdout)
assert result.returncode==0
checks["wheel_smoke_exit"]=result.returncode
mutations={}
for mode in ("R1","R2","R3"):
    result=run("mutation-"+mode,[PY,str(ROOT/"mutate_repair.py"),mode])
    assert result.returncode==1 and "AssertionError" in result.stdout and "ERROR collecting" not in result.stdout
    mutations[mode]={"exit":result.returncode,"tail":result.stdout.splitlines()[-1]}
checks["mutation_results"]=mutations
count=0
for record in subprocess.check_output(["git","ls-tree","-r","-z",SHA],cwd=WORKTREE).split(b"\0"):
    if not record:
        continue
    info,path=record.split(b"\t",1)
    _,kind,digest=info.split()
    assert kind==b"blob"
    content=(SOURCE/path.decode()).read_bytes()
    assert hashlib.sha1(b"blob "+str(len(content)).encode()+b"\0"+content).hexdigest()==digest.decode(),path
    count+=1
checks["unmodified_archived_git_blobs"]=count
(ROOT/"checks.json").write_text(json.dumps(checks,indent=2)+"\n")
print(json.dumps(checks,indent=2),flush=True)
