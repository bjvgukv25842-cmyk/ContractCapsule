"""Lock the minimal independent evidence set without source/fixture/private keys."""
import hashlib
import json
from pathlib import Path

root=Path(__file__).parent.resolve()
names=["REPORT.md","run_audit.py","supplemental.py","mutate_repair.py","make_export_manifest.py","probes/test_prior_findings.py","probes/test_failure_interactions.py","commands.jsonl","checks.json","node-retention.json"]
names+=sorted(str(p.relative_to(root)) for p in (root/"logs").glob("*.log"))
records={}
for name in names:
    data=(root/name).read_bytes()
    records[name]={"sha256":hashlib.sha256(data).hexdigest(),"bytes":len(data)}
value={"verdict":"PASS (technical)","technical_commit":"bb1d56daecbc31240b5ea1371378c50e63dd9c4b","root":str(root),"artifacts":records}
(root/"artifact-manifest.json").write_text(json.dumps(value,indent=2)+"\n")
print("EXPORT_FILES",len(records),"TOTAL_BYTES",sum(v["bytes"] for v in records.values()))
print("REPORT_SHA256",records["REPORT.md"]["sha256"])
