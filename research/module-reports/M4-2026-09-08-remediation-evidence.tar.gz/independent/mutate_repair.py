"""Restore an exact pre-repair method in memory, never in audited files."""
import ast
from pathlib import Path
import sys
from unittest.mock import patch
import pytest
from contractcapsule.compile import session
from contractcapsule.resolve import graph

ROOT=Path(__file__).parent.resolve()
mode=sys.argv[1]
if mode=="R1":
    module,relative,owner,method=graph,"resolve/graph.py",graph._Assembly,"explicit"
    targets=["tests/unit/test_graph_owner_admission.py"]
elif mode=="R2":
    module,relative,owner,method=session,"compile/session.py",session.Compilation,"_select"
    targets=["tests/integration/test_m4_exit_repairs.py","-k","compiler_owns_optional_class_precedence or compiler_preserves_rank_order_within_one_class"]
else:
    assert mode=="R3"
    module,relative,owner,method=session,"compile/session.py",session.Compilation,"failure"
    targets=["tests/integration/test_m4_exit_repairs.py"]
source=ROOT/"before/src/contractcapsule"/relative
tree=ast.parse(source.read_text())
class_node=next(node for node in tree.body if isinstance(node,ast.ClassDef) and node.name==owner.__name__)
function=next(node for node in class_node.body if isinstance(node,ast.FunctionDef) and node.name==method)
namespace=dict(vars(module))
exec(compile(ast.Module(body=[function],type_ignores=[]),str(source),"exec"),namespace)
print("INJECTED_EXACT_OLD_METHOD",mode,str(source),owner.__name__,method,flush=True)
with patch.object(owner,method,namespace[method]):
    sys.exit(pytest.main([*targets,"-v","-p","no:cacheprovider"]))
