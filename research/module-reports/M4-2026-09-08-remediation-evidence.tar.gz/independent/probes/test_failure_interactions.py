"""Remaining shared failure/replay boundaries after authorized R3 repair."""
from unittest.mock import patch
import pytest
from contractcapsule.compile.budget import LocalTokenCounter
from contractcapsule.compile.session import Compilation
from contractcapsule.compile import session
from contractcapsule.models.view import ViewBudget
from contractcapsule.resolve.rank import FTS5BM25Ranker
from tests.integration.test_compile_view import pipeline
from tests.m4_helpers import M4Fixture

@pytest.fixture(scope="module")
def counter():
    return LocalTokenCounter("shared-failure-audit")

def private_case(tmp_path,counter,compression="P0_EXACT"):
    fixture=M4Fixture.create(tmp_path)
    pub=fixture.publish(capsule_id="com.private.boundary",atoms=({"atom_id":"private-boundary","statement":"token "*800,"compression_class":compression},))
    return pipeline(fixture,(pub,),counter)

def withheld(view):
    assert not view.validation.valid and not view.content and not view.evidence_handles
    assert not view.manifest.decisions and not view.manifest.capsules
    assert view.manifest.request_digest=="sha256:"+"0"*64
    assert view.manifest.permission_digest=="sha256:"+"0"*64
    assert view.manifest.rejected_counts=={"AUTHORIZATION_SNAPSHOT_INVALIDATED":1}
    assert "private-boundary" not in view.model_dump_json()

def test_replay_mismatch_after_revocation_withholds_old_projection(tmp_path,counter):
    compiler,request=private_case(tmp_path,counter)
    original=session.view_manifest_digest
    def revoke_at_output(manifest):
        digest=original(manifest)
        object.__setattr__(compiler.authorizer,"grants",())
        return digest
    with patch.object(session,"view_manifest_digest",revoke_at_output):
        view=compiler.compile_view(request.model_copy(update={"expected_manifest_digest":"sha256:"+"0"*64}))
    assert view.validation.blockers==("REPLAY_MISMATCH",)
    withheld(view)

def test_unknown_reauthorization_failure_does_not_leak_original_error(tmp_path,counter):
    compiler,request=private_case(tmp_path,counter)
    def broken(*args):
        object.__setattr__(compiler.authorizer,"grants",None)
        raise RuntimeError("PRIVATE /source/private-boundary")
    with patch.object(FTS5BM25Ranker,"rank_atoms",broken):
        view=compiler.compile_view(request)
    assert view.validation.blockers==("RANKING_FAILED",)
    withheld(view)
    assert "PRIVATE" not in view.model_dump_json()

def test_still_authorized_p1_overflow_preserves_real_attempt(tmp_path,counter):
    compiler,request=private_case(tmp_path,counter,"P1_STRUCTURED")
    view=compiler.compile_view(request.model_copy(update={"budget":ViewBudget(model_input_tokens=500)}))
    assert view.validation.blockers==("P1_OVERFLOW",)
    assert not view.content and view.manifest.tokens.total>500
    assert view.manifest.decisions[0].atom_id=="private-boundary"
    assert not view.manifest.rejected_counts

def test_redaction_does_not_clear_transaction_evidence(tmp_path,counter):
    compiler,request=private_case(tmp_path,counter)
    from contractcapsule.compile.evidence import NativeEvidenceResolver
    original_read=NativeEvidenceResolver.resolve
    original_result=Compilation._result
    calls=0
    captured={}
    def revoke_after_read(self,*args):
        nonlocal calls
        result=original_read(self,*args)
        calls+=1
        if calls==2:
            object.__setattr__(self.authorizer,"grants",())
        return result
    def capture(self,report,*,redact=False):
        result=original_result(self,report,redact=redact)
        captured.update(tokens=self.tokens.total,selected=set(self.selected),evidence=bool(self.evidence),redact=redact)
        return result
    with patch.object(NativeEvidenceResolver,"resolve",revoke_after_read),patch.object(Compilation,"_result",capture):
        view=compiler.compile_view(request)
    withheld(view)
    assert captured["tokens"]>0 and captured["evidence"] and captured["redact"]
    assert captured["selected"]=={"private-boundary"}
    assert view.manifest.tokens.total==0
