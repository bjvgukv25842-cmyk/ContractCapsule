"""Original independent findings, adapted only to test a known fixed budget."""
from dataclasses import replace
from unittest.mock import patch
import pytest
from contractcapsule.compile.budget import LocalTokenCounter
from contractcapsule.compile.evidence import NativeEvidenceResolver
from contractcapsule.models.view import ViewBudget,view_manifest_digest
from contractcapsule.resolve.rank import FTS5BM25Ranker
from tests.integration.test_compile_view import pipeline,selection
from tests.m4_helpers import M4Fixture

@pytest.fixture(scope="module")
def counter():
    return LocalTokenCounter("independent-audit")

def test_fixed_class_priority_survives_valid_rank_order(tmp_path,counter):
    fixture=M4Fixture.create(tmp_path)
    pub=fixture.publish(atoms=(
        {"atom_id":"p2","statement":"token required evidence. "*70,"compression_class":"P2_EVIDENCE"},
        {"atom_id":"p3","statement":"token background history. "*70,"compression_class":"P3_SUMMARY"},
    ))
    compiler,request=pipeline(fixture,(pub,),counter)
    class ReverseRanker:
        version="1.0.0"
        config_digest="sha256:"+"1"*64
        def rank_atoms(self,atoms,task):
            return list(reversed(FTS5BM25Ranker().rank_atoms(atoms,task)))
    full=compiler.compile_view(request)
    assert full.validation.valid and selection(full)=={"p2","p3"}
    constrained=request.model_copy(update={"budget":ViewBudget(model_input_tokens=1400)})
    native=compiler.compile_view(constrained)
    alternate=replace(compiler,ranker=ReverseRanker()).compile_view(constrained)
    print("PRIORITY",native.validation.valid,sorted(selection(native)),alternate.validation.valid,sorted(selection(alternate)))
    assert native.validation.valid and alternate.validation.valid
    assert selection(native)==selection(alternate)=={"p2"}

def test_late_revocation_does_not_export_now_denied_identity(tmp_path,counter):
    fixture=M4Fixture.create(tmp_path)
    pub=fixture.publish(capsule_id="com.private.identifier",atoms=({"atom_id":"private-identity","compression_class":"P0_EXACT"},))
    compiler,request=pipeline(fixture,(pub,),counter)
    original=NativeEvidenceResolver.resolve
    calls=0
    def revoke_after_read(self,*args):
        nonlocal calls
        result=original(self,*args)
        calls+=1
        if calls==2:
            object.__setattr__(self.authorizer,"grants",())
        return result
    with patch.object(NativeEvidenceResolver,"resolve",revoke_after_read):
        view=compiler.compile_view(request)
    assert calls==2 and not view.validation.valid and view.content==""
    print("REVOKED_MANIFEST",view.manifest.model_dump_json())
    assert "private-identity" not in view.model_dump_json()
    assert "com.private.identifier" not in view.model_dump_json()

def test_runtime_version_and_replay_stamps(tmp_path,counter):
    from contractcapsule.compile.schema import validate_view_manifest
    fixture=M4Fixture.create(tmp_path)
    pub=fixture.publish(atoms=({"compression_class":"P0_EXACT"},))
    compiler,request=pipeline(fixture,(pub,),counter)
    view=compiler.compile_view(request)
    assert view.validation.valid
    assert view.manifest.compiler_version=="0.1.2"
    stamps={stamp.name:stamp for stamp in view.manifest.services}
    assert stamps["compiler"].version=="0.1.2" and stamps["graph"].version=="1.0.1"
    validate_view_manifest(view.manifest.model_dump(mode="json"))
    again=compiler.compile_view(request.model_copy(update={"expected_manifest_digest":view_manifest_digest(view.manifest)}))
    assert again==view
    old=view.manifest.model_copy(update={"compiler_version":"0.1.0"})
    denied=compiler.compile_view(request.model_copy(update={"expected_manifest_digest":view_manifest_digest(old)}))
    assert denied.validation.blockers==("REPLAY_MISMATCH",) and not denied.content
    assert denied.manifest.compiler_version=="0.1.2"
