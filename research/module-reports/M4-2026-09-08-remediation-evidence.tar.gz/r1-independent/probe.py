import ast
import importlib.util
from pathlib import Path
import sys
import tempfile

import pytest
from contractcapsule.resolve import graph
from tests.unit.test_dependency_closure import ReusedApprovalFixture, admit, dependencies, edge
from tests.unit.test_eligibility import task_context

root = Path(__file__).parent
mode = sys.argv[1]
print('ACTUAL GRAPH SOURCE:', graph.__file__)
if mode == 'mutation':
    # Restore only the old guard in memory. Nothing is written to either tree.
    tree = ast.parse((root/'base/src/contractcapsule/resolve/graph.py').read_text())
    cls = next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='_Assembly')
    method = next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='explicit')
    exec(compile(ast.Module(body=[method],type_ignores=[]),'<old-guard-mutation>','exec'), graph.__dict__)
    graph._Assembly.explicit = graph.explicit
    sys.exit(pytest.main(['-vv','-p','no:cacheprovider','--basetemp',str(root/'pytest-mutation'),
                         'tests/unit/test_graph_owner_admission.py']))

# Independently re-run the original reviewer fixture, without the new helper.
location = Path(tempfile.mkdtemp(prefix=f'{mode}-original-',dir=root))
fixture = ReusedApprovalFixture.create(location)
first = fixture.publish(atoms=({'atom_id':'a','scope':('path:src/only.py',)},))
def narrow(raw):
    raw['control_manifest']['scope']['paths']=['src/other/**']
    dependencies((),(),(edge('a','absent'),))(raw)
second=fixture.publish(capsule_id='com.example.second',amend=narrow)
task=task_context(paths=('src/only.py','src/other/file.py'))
admission=admit(fixture,(first,second),task)
print('ADMISSION:',[(x.published.capsule.control_manifest.capsule_id,x.atom_ids) for x in admission.items])
resolved=graph.resolve_graph(admission,task)
try:
    print('ORIGINAL REPRO CLOSURE:',sorted(resolved.close_atoms({'a'})))
except Exception as error:
    print('ORIGINAL REPRO BLOCKER:',type(error).__name__,str(error))
print('GRAPH VERSION:',resolved.version,'CONFIG:',resolved.config_digest)

spec=importlib.util.spec_from_file_location('r1_tests',root/'candidate/tests/unit/test_graph_owner_admission.py')
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
for name in ('test_denied_source_owner_does_not_contribute_edges',
             'test_admitted_shared_owner_keeps_its_declaration',
             'test_compile_ignores_denied_shared_owner_declarations'):
    for kind in ('requires','conflicts'):
        location=Path(tempfile.mkdtemp(prefix=f'{mode}-direct-',dir=root))
        try:
            getattr(module,name)(location,kind)
            print(name,kind,'PASS')
        except BaseException as error:
            print(name,kind,'FAIL',type(error).__name__,str(error))
