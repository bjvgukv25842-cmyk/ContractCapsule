# Independent M4-R1 Repair Review

Date: 2026-09-08. Scoped specification verdict: PASS. Scoped code-quality
verdict: PASS. No actionable finding remains within the approved R1 repair.

Exact tested candidate: `19689c8e64ef818f9c31abc221a8ccf70bea85b4`.
Exact tested base: `44585274b5fd639df6b76ea85825a007b01b1c48`.
These are independent physical-path Git archives in this directory, not the
live remediation worktree. Only graph.py and test_graph_owner_admission.py
change between the two commits. Concurrent R2/R3 work is excluded.

## Evidence and Reasoning

`src/contractcapsule/resolve/graph.py:309` now checks that the exact declaring
CapsuleRef belongs to the source node's currently admitted owners, instead of
accepting any globally admitted owner. `inventory` admits only per-publication
atom_ids (lines142-144), and `_admit_atom` records those exact owners
(lines156-158). Consequently a denied occurrence cannot borrow another
publication's admitted occurrence of the identical atom to add an explicit
requires or conflicts edge. The skipped denied occurrence is not treated as
authority, while the authorized occurrence remains usable.

The foreign-payload ownership check (lines298-303) and exact declaring capsule
source binding (lines304-305) remain intact. A real admitted shared owner
retains its own declarations, and consumer-owned exact dependency locks are
unchanged. No schema, policy or public interface expansion is introduced.

Graph service version at line69 and config version at line399 both become
1.0.1. Independent output confirms the config digest changes from
`sha256:386760022b3bf1ca1f1461e8534d4ee93992f393fd3f4d2246bc963beb94c960`
to `sha256:fa8ae4fb2c3543c9b6941913e0d5bc8497a3cb004bb47b95538d578ddfa3f359`.
This records the changed graph interpretation without rewriting A-zone data.

Basis: approved M4-R1 scope in
research/module-reports/M4-2026-09-08-independent-exit-audit.md:41-58,
CCS-2.1 sections6/9/14.2 and invariant5, and accepted ADR-0004 per-member
admission/consumer ownership. The controller explicitly conveyed the author's
approval of R1/R2/R3; this reviewer was assigned R1 only.

## Independently Executed Tests

| Run | Result | Meaning |
| --- | --- | --- |
| Candidate three-file persistent pytest | exit0; 64 passed in8.07s | 6 new R1 +49 original graph +9 prior service cases |
| Original reviewer reproduction against base | reports MISSING_DEPENDENCY | independently reconfirms old residual defect |
| Original reviewer reproduction against candidate | closure ['a'] | defect corrected with unchanged admission [('a',),()] |
| Six new assertions directly against base | 4 failures,2 passes; diagnostic exit0 | denied-owner graph and publiccompile fail; positive shared-owner cases pass |
| Six new assertions directly against candidate | 6 passes; diagnostic exit0 | same assertions on fixed services |
| Process-local old-guard mutation on candidate | pytest exit1; 4 failed,2 passed in1.07s | regressions detect removal of exact admitted-owner requirement |
| Fresh post-mutation candidate pytest | exit0;6 passed | separate fresh process confirms no persisted mutation |
| Committed diff --check | exit0 | no whitespace errors |

All results above were run by this reviewer, not taken from the implementation
report. The author's 751 full-suite passes and lint/typecheck results are NOT
represented as independently run here.

New persistent cases and mutation behavior:

- test_denied_source_owner_does_not_contribute_edges[requires]: candidate pass;
  old guard fails with MISSING_DEPENDENCY.
- test_denied_source_owner_does_not_contribute_edges[conflicts]: candidate pass;
  old guard retains a forbidden self-conflict and fails.
- test_admitted_shared_owner_keeps_its_declaration[requires]: passes both;
  genuinely admitted owner's missing dependency is still blocking.
- test_admitted_shared_owner_keeps_its_declaration[conflicts]: passes both;
  genuinely admitted owner's declared conflict is still present.
- test_compile_ignores_denied_shared_owner_declarations[requires]: candidate
  pass; old guard fails with invalid view/MISSING_DEPENDENCY.
- test_compile_ignores_denied_shared_owner_declarations[conflicts]: candidate
  pass; old guard fails with invalid view/CONFLICT.

The other persistent tests include exact-release capsule-source behavior,
foreign atom/capsule requires/conflicts, precise consumer locks, full provider
units, pure closure/conflicts/cycles, and the prior nine service regressions.
Existing Git regression setup uses only a local file:// partial clone; its
diagnostic disables transport. No network or external service was requested.

## Reproduction and Logs

Runner: `/private/tmp/m4-r1-review.jlzmcf/run.py`.
Diagnostic/mutation: `/private/tmp/m4-r1-review.jlzmcf/probe.py`.
Raw outputs: candidate.log, base.log, independent.log, mutation.log, final.log.
All original failures are retained. No production test assertion was changed.

Commands executed:

```bash
'/Users/litmus/Documents/Contract Capsule/.worktrees/m4-exit-remediation/.venv/bin/python' /private/tmp/m4-r1-review.jlzmcf/run.py candidate
'/Users/litmus/Documents/Contract Capsule/.worktrees/m4-exit-remediation/.venv/bin/python' /private/tmp/m4-r1-review.jlzmcf/run.py base
'/Users/litmus/Documents/Contract Capsule/.worktrees/m4-exit-remediation/.venv/bin/python' /private/tmp/m4-r1-review.jlzmcf/run.py mutation
'/Users/litmus/Documents/Contract Capsule/.worktrees/m4-exit-remediation/.venv/bin/python' /private/tmp/m4-r1-review.jlzmcf/run.py independent
'/Users/litmus/Documents/Contract Capsule/.worktrees/m4-exit-remediation/.venv/bin/python' /private/tmp/m4-r1-review.jlzmcf/run.py final
```

The runner logs full subprocess commands, cwd, PYTHONPATH and exits. Tests use
Python3.12.13/pytest9.1.1, PYTHONDONTWRITEBYTECODE=1, disabled pytest cache and
external fixture/Hypothesis directories. Source selection is explicit archive
src/tests via PYTHONPATH. probe.py prints the actual graph.__file__ for each
diagnostic process.

Base direct checks import the candidate's new test definitions using importlib,
but all production and existing helper imports come from the base archive.
Those are direct assertions, not a base pytest collection claim. Their exit0
is intentional because failures are printed and retained; it does not mean
the base passed. The independent original fixture does not use the new
shared_owner_case helper. All publication/approval/Registry/admission paths are
genuine test-fixture paths, not fabricated authority objects.

Mutation parses base graph.py with ast, extracts only _Assembly.explicit and
replaces that method in the candidate process. The only behavioral difference
in that method is the repaired guard. The process leaves graph version/config
at1.0.1, and modifies no source file. Separate process-local tests provide the
unmutated final pass. These extra invocations are not counted as additional
unique persistent cases beyond the64-node run.

Reruns should use a fresh copied reviewer directory or fresh log/basetemp names
so the existing logs and pytest fixture evidence remain recoverable.

## Frozen Inputs and Limits

Completely reread AGENTS, CCS-2.1, the frozen execution plan, accepted ADR-0004,
and the approved R1 problem/repair scope. Used code-review-and-quality guidance.
Candidate frozen digests matched before testing and again after testing:

- CCS-2.1: aaddaa8def8df1ef2efbe4f9487de0ba86a60ae5aed8955ca76f5e070fa01e5c
- frozen plan: 7c1feebb36776c09de5c0ba5462540072374b9902d8e04d405585a8efb8659c0
- candidate graph.py: ed943d63137cce2068c275bfb67836567c25172e559478717791ec73a821be6e
- new regression file: cde272f4d23d34bdb2512935d1e4d5cedb4caae272848fb6e28b9d229befe816

No worktree, branch, index, source or governance edits; no subagents or fixes.
Only reviewer-owned temporary diagnostics, logs, and test fixtures were created.
No full compiler/global gate, full-suite, lint/typecheck, build, dependency-lock,
or research result claim is made. R2/R3 and final combined-candidate audit remain
separate obligations. This PASS closes the scoped technical R1 finding only,
not M4's author exit. M5 was not started and no schedule/gate was changed.
