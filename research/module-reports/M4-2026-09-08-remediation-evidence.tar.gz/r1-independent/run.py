import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).parent
mode = sys.argv[1]
tree = root / ('base' if mode == 'base' else 'candidate')
python = '/Users/litmus/Documents/Contract Capsule/.worktrees/m4-exit-remediation/.venv/bin/python'
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONPATH=f'{tree}/src:{tree}',
           HYPOTHESIS_STORAGE_DIRECTORY=str(root/'hypothesis'))
if mode in {'candidate', 'final'}:
    args = ['-m','pytest','-vv','-p','no:cacheprovider','--basetemp',str(root/'pytest-candidate'),
            'tests/unit/test_graph_owner_admission.py','tests/unit/test_dependency_closure.py',
            'tests/unit/test_service_review_regressions.py']
    if mode == 'final':
        args = ['-m','pytest','-q','-p','no:cacheprovider','--basetemp',str(root/'pytest-final'),
                'tests/unit/test_graph_owner_admission.py']
else:
    args = [str(root/'probe.py'),mode]
command = [python,*args]
result = subprocess.run(command,cwd=tree,env=env,capture_output=True,text=True,timeout=60)
log = f'COMMAND: {command!r}\nCWD: {tree}\nPYTHONPATH: {env["PYTHONPATH"]}\nEXIT: {result.returncode}\n{result.stdout}\n{result.stderr}'
(root/f'{mode}.log').write_text(log)
print(log)
sys.exit(result.returncode)
